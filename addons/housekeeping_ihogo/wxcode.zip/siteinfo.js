var siteinfo = {
  "m": 'housekeeping_ihogo',
  "uniacid": "13",
  "acid": "13",
  "multiid": "0",
  "version": "1.0.0",
  "siteroot": "https://ihogo.net/.web/we7site/app/index.php",
  'method_design': '3'
};
module.exports = siteinfo;    